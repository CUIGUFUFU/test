package cn.lcz.mapper;

import cn.lcz.domain.FictionShelf;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


public interface FictionShelfMapper extends BaseMapper<FictionShelf> {

}
