package cn.lcz.mapper;

import cn.lcz.domain.Chapter;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


public interface ChapterMapper extends BaseMapper<Chapter> {

}
