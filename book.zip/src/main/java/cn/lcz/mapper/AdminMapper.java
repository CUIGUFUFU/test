package cn.lcz.mapper;

import cn.lcz.domain.Admin;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


public interface AdminMapper extends BaseMapper<Admin> {
}
