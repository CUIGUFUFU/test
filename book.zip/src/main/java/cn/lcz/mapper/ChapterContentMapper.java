package cn.lcz.mapper;

import cn.lcz.domain.ChapterContent;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface ChapterContentMapper extends BaseMapper<ChapterContent> {

}
