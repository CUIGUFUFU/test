package cn.lcz.mapper;

import cn.lcz.domain.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


public interface UserMapper extends BaseMapper<User> {

}
