package cn.lcz.domain;

import lombok.Data;

/**
 * 管理员页面
 */
@Data
public class Admin {
    private int adminId;
    private String adminName;
    private String adminPassword;
}
