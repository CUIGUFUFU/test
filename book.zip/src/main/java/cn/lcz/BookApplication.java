package cn.lcz;

import org.mybatis.spring.annotation.MapperScan;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.EnableScheduling;

import java.net.InetAddress;
import java.net.UnknownHostException;

@SpringBootApplication
@MapperScan("cn.lcz.mapper") // 扫描 Mapper 接口所在的包
@EnableScheduling // 启用定时任务
public class BookApplication {

    // 日志记录器
    public final static Logger log = LoggerFactory.getLogger(BookApplication.class);

    // 主方法
    public static void main(String[] args) throws UnknownHostException {
        // 运行 Spring Boot 应用，并获取上下文对象
        ConfigurableApplicationContext application = SpringApplication.run(BookApplication.class, args);
        // 获取运行环境
        Environment env = application.getEnvironment();
        // 获取本地主机地址
        String ip = InetAddress.getLocalHost().getHostAddress();
        // 获取服务器端口号
        String port = env.getProperty("server.port");
        // 获取Servlet上下文路径
        String path = env.getProperty("server.servlet.context-path");

        // 输出启动成功信息
        log.info("\n----------------------------------------------------------\n\t" +
                "程序启动成功! URLs:\n\t" +
                "首页: \t\thttp://localhost:" + port + path + "/index" + "\n\t" +
                "爬虫地址: \thttp://" + ip + ":" + port + path + "/sys/index" + "\n\t" +
                "管理员页面：\thttp://localhost:" + port + path + "/admin/index" + "\n\t" +
                "----------------------------------------------------------");
    }

}
