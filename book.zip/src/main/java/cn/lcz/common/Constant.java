package cn.lcz.common;

public class Constant {


    /**
     * 小说抓取发生异常次数则放弃
     */
    public static final int WRITE_NUMBER = 1000;


}
