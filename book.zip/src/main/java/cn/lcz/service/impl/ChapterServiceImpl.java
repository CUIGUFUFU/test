package cn.lcz.service.impl;

import cn.lcz.domain.Chapter;
import cn.lcz.mapper.ChapterMapper;
import cn.lcz.service.IChapterService;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class ChapterServiceImpl extends ServiceImpl<ChapterMapper, Chapter> implements IChapterService {

    @Override
    public List<Chapter> queryByFictionIdList(int fictionId) {
        QueryWrapper<Chapter> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("fiction_id", fictionId);
        return list(queryWrapper);
    }

    @Override
    public Chapter netChapter(int fiction_id, int sort) {
        QueryWrapper<Chapter> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("fiction_id", fiction_id);
        queryWrapper.eq("sort", sort);
        return getOne(queryWrapper);
    }

}
