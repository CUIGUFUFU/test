package cn.lcz.service.impl;

import cn.lcz.domain.ChapterContent;
import cn.lcz.mapper.ChapterContentMapper;
import cn.lcz.service.IChapterContentService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;


@Service
public class ChapterContentServiceImpl extends ServiceImpl<ChapterContentMapper, ChapterContent> implements IChapterContentService {

}
