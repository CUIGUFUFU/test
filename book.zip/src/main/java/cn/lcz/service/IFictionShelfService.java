package cn.lcz.service;

import cn.lcz.domain.FictionShelf;
import cn.lcz.utils.Result;
import cn.lcz.vo.ShelfVo;
import com.baomidou.mybatisplus.extension.service.IService;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

public interface IFictionShelfService extends IService<FictionShelf> {

    /**
     * 添加小说到书架
     */
    Result addShelf(HttpServletRequest request, int fiction_id);

    /**
     * 是否已经保存到书架
     * 0 表示未添加或者未登录
     * 1 表示保存到了书架
     */
    int isShelf(HttpServletRequest request, int fictionId);

    /**
     * 查找用户的所有书
     */
    List<ShelfVo> queryByUserId(int userId) throws Exception;

    /**
     * 更新用户阅读章节
     */
    int updateShelf(int fictionId, int userId, int sort);

    /**
     * 从书架删除小说
     */
    int deleteShelf(int id, int userId);
}
