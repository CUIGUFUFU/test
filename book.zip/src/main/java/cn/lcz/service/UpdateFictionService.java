package cn.lcz.service;

public interface UpdateFictionService {

    void updateFiction(int fiction_id, String url);

}
