package cn.lcz.service;

import cn.lcz.common.DataGridView;
import cn.lcz.domain.Fiction;
import cn.lcz.vo.FictionVo;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;


public interface IFictionService extends IService<Fiction> {

    /**
     * 模糊查询
     *
     * @param v 字符串
     * @return list
     */
    List<Fiction> queryLike(String v);

    /**
     * @param fictionVo vo
     * @return
     */
    DataGridView queryAllFiction(FictionVo fictionVo);

    /**
     * 小说点击量
     */
    void addView(Fiction fiction);

}
