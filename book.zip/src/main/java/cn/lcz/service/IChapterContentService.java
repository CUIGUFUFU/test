package cn.lcz.service;

import cn.lcz.domain.ChapterContent;
import com.baomidou.mybatisplus.extension.service.IService;

public interface IChapterContentService extends IService<ChapterContent> {
}
