package cn.lcz.service;


import cn.lcz.domain.Fiction;
import org.jsoup.nodes.Document;

public interface WriteFictionService {

    void insert(String fictionURL);

    Fiction getFictions(Document document);

}
