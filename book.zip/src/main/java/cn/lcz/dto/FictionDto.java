package cn.lcz.dto;

import lombok.Data;

/**
 * 服务层参数
 */
@Data
public class FictionDto {

    private String type;
    private String state;
    private String fiction_name;

}
